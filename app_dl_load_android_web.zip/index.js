let isAndroid = false;
let pTag;

window.onload = () => {
    console.log("Document loaded");
    pTag = document.getElementById("device-type");
    downloadButton = document.getElementById("download-button");

    isAndroid = /(android)/i.test(navigator.userAgent);
    if(isAndroid)
    {
        pTag.innerText = "Android device";
        downloadButton.disabled = false;
    }
    else
    {
        pTag.innerText = "Not Android device";
        downloadButton.disabled = true;
    }
}

function launchButtonClicked(){
    pTag.innerText = "You clicked install"
    if(isAndroid)
    {
        pTag.innerText = "You clicked install"
        window.location.href = "intent://open.my.app/#Intent;scheme=app;package=com.acc.apkinstaller;S.browser_fallback_url=http://192.168.29.30:8889/assets/apk_installer_13-10.apk;end";
    }
}